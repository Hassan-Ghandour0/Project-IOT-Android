from grovepi import *
from grove_rgb_lcd import *
import time
import serial
import grovepi
import math
import socket
import json
import requests
import errno

# Connection du capteur ultrason au port D6
ultrasonic_ranger = 6

# Connection du capteur de température et humidité au port D4 - Sur Grove, seul le capteur bleu est utilisé
sensor = 4
blue = 0    

# Initialisation de l'écran LCD
try:
    setRGB(0, 0, 0) 
    setText("")
except Exception as e:
    print("Error initializing LCD:", e)

# Configuration du scanner de code-barres
ser = serial.Serial(
        port='/dev/ttyUSB0',
        baudrate = 9600,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
        timeout=0.01
)


# Initialisation du réseau  pour les informations json
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = '10.224.0.210'  # Adresse ip du raspberry
port = 9999  # Port de destination
server_socket.bind((host, port))
server_socket.listen(1)
server_socket.setblocking(False)


#Initialisation des paramètres de temps pour le chronomètre
start_time = time.time()
open_door_time = 0  


#Initialisation des fonctions pour le code barre
barcode_int = 0
product_name = ''

def get_product_info(upc):
    global product_name
    url = f"https://world.openfoodfacts.org/api/v0/product/{upc}.json"
    response = requests.get(url)
    data = response.json()

    if response.status_code == 200 and 'product' in data:
        product = data['product']
        product_name = product.get('product_name', 'Product name not available')
        image_url = product.get('image_url', 'No image available')
        return product_name, image_url
    else:
        return "Product not found", None
    barcode_int=0

def mainAPI(upc):
    product_name, image_url = get_product_info(upc)
    print("Nom du produit:", product_name)
    print("URL de l'image:", image_url)
    setText(product_name)
    setRGB(0,255,0) #Vert
    time.sleep(1.5)
    setRGB(0,0,0)



print("L'écran devient blanc lorsque la porte est ouverte.")


while True:
    try:
        client_socket = None
        #Recherche le port pour envoyer les fichiers json
        try:
            client_socket, addr = server_socket.accept()
        except socket.error as e:
            # Erreur si aucun client n'essaie de se connecter
            if e.errno != errno.EWOULDBLOCK:
                raise  # Une erreur autre que "operation would block"
            client_socket = None

        if client_socket is not None:
            print("Connexion de", addr)



        barcode_int = 0
        #Scanne un code barre et adapte l'écran LCD
        while ser.inWaiting() > 0:
            while barcode_int == 0:
                barcode = ser.readline().decode('utf-8').strip()
                barcode_int = int(barcode)
                print("Code barre reçu:", barcode)
                mainAPI(barcode_int)
            open_door_time = 0  #Réinitialise le temps d'ouverture de la porte lorsque l'on range les produit



        
        distance = ultrasonicRead(ultrasonic_ranger) # Lecture du capteur ultrason

        # Si la porte est ouverte (distance > 5cm) : 
        if distance > 5:
            # Incrémente le temps écoulé depuis la dernière distance supérieure à 5 cm
            open_door_time += time.time() - start_time
            setRGB(255,255,255) #Blanc
            
            # Si la porte est ouverte depuis plus de 10s :
            if open_door_time >= 10:
                # Message d'érreur sur l'écran LCD
                setRGB(0, 0, 0)
                time.sleep(0.2)
                setRGB(255, 0, 0) #Rouge
                setText("Porte Ouverte.\nFermez la porte.")
                


        #Si Porte fermée (distance <= 5cm)    
        else:
            open_door_time = 0 #Réinitialise le chronomètre
            setRGB(0, 0, 0) #Éteins l'écran
            setText("")
           

        [temp,humidity] = grovepi.dht(sensor,blue)
        if math.isnan(temp) == False and math.isnan(humidity) == False:
            temp_frigo = temp
            hum_frigo = humidity
            print("temp = %.02f C humidity =%.02f%%"%(temp_frigo, hum_frigo))

        #Transforme les informations des capteurs en json    
        data = {
            "température": temp_frigo,
            "humidité": hum_frigo,
            "nom_produit": product_name
        }

        if client_socket:
            json_data = json.dumps(data)
            client_socket.sendall(json_data.encode('utf-8'))
            client_socket.close()

        start_time = time.time()
        time.sleep(0.2)  # Attendez 0.2 seconde avant la prochaine lecture
        


    except KeyboardInterrupt:
        server_socket.close()
        break
    except TypeError:
        print("Error")
    except IOError:
        print("Error")

