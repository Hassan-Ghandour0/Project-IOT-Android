package com.example.alcoolinkapp

import androidx.lifecycle.LiveData

class ProductRepository(private val productDao: ProductDao) {

    val getAllProduct: LiveData<List<Product>> = productDao.getAllProduct()
    val getGPTProduct: LiveData<List<Product>> = productDao.getGPTProduct()

    suspend fun addProduct(product: Product){
        productDao.insertProduct(product)
    }
    suspend fun deleteProduct(product: Product){
        productDao.deleteProduct(product)
    }
    suspend fun getAllProduct(product: Product){
        productDao.getAllProduct()
    }

}