package com.example.alcoolinkapp

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


@Database (entities= [Product::class], version=1)
abstract class ProductDatabase: RoomDatabase() {

    abstract fun productDao() : ProductDao

    companion object{
        @Volatile
        private var instance : ProductDatabase? = null
        private val LOCK = Any()

        operator fun invoke(context: Context) = instance ?: synchronized(LOCK){
            instance?: getDatabase(context).also {
                instance = it
            }
        }

        fun getDatabase (context : Context)=
            Room.databaseBuilder(context.applicationContext,ProductDatabase::class.java, "Product.db").build()

    }}