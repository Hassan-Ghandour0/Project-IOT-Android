package com.example.alcoolinkapp.services.network

import com.example.alcoolinkapp.services.SensorService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object NetworkModule {
    private val retrofit = Retrofit.Builder()
        .baseUrl("http://10.224.0.210:9999")  // IP and Port
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val sensorService: SensorService = retrofit.create(SensorService::class.java)
}