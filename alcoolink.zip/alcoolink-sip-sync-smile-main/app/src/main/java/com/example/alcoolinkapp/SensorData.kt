package com.example.alcoolinkapp

data class SensorData(
    val temperature: Double,
    val humidity: Double,
    val distance: Double,
    val barcodeName : String
)