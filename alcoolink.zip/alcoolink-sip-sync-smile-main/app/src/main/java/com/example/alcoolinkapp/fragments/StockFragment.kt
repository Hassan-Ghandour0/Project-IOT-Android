package com.example.alcoolinkapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.alcoolinkapp.ProductAdapter
import com.example.alcoolinkapp.ProductViewModel
import com.example.alcoolinkapp.R

class StockFragment : Fragment() {

    lateinit var productAdapter: ProductAdapter
    lateinit var productViewModel: ProductViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_stock, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val btnNextPage: Button = view.findViewById(R.id.buttonPage10)
        btnNextPage.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_stockFragment_to_mrcuisineFragment)
        }

        val btnNextPage2: Button = view.findViewById(R.id.buttonPage11)
        btnNextPage2.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_stockFragment_to_optionFragment)
        }

        val btnNextPage3: Button = view.findViewById(R.id.buttonPage12)
        btnNextPage3.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_stockFragment_to_remplirViderFragment)
        }
    }
/*
    override fun onItemClick(Product: Product) {
        ProductViewModel.delete(Product)
        produitsAdapter.notifyDataSetChanged()
        Toast.makeText(applicationContext,"Produit supprimé", Toast.LENGTH_SHORT).show()

    }
 */
}