package com.example.alcoolinkapp.services

//imports
import android.util.Log
import com.example.alcoolinkapp.services.network.RetrofitSetup
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface ChatGPTService {

    @Headers(
        "Content-Type: application/json",
        "Authorization: Bearer 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"

    )

    @POST("chat/completions")
    suspend fun getCompletion(
        @Body requestBody: RequestBody
    ): Response<ResponseBody>
}


suspend fun getResponse(question: String): String {
    val requestBody = """
        {
            "context": "$question",
            "model": "gpt-3.5-turbo-1106",
            "temperature": 0.7,
            "max_tokens": 150
        }
    """.trimIndent()

    val requestBodyJson = requestBody.toRequestBody("application/json".toMediaTypeOrNull())

    return try {
        val response = RetrofitSetup.service.getCompletion(requestBodyJson)
        Log.d("Retrofit", "Response code: " + response.code())
        Log.d("Retrofit", "Response body: " + response.body().toString())

        if (response.isSuccessful) {
            val responseBody = response.body()
            responseBody?.string() ?: "Is our chef really out of ideas ?"
        } else {
            "We could not reach our chef, our apologies :("
        }
    } catch (e: Exception) {
        e.printStackTrace()
        ""
    }
}


//class APIService {
    /*
    fun gptListener(){
        val txtResponse=findViewById<TextView>(R.id.txtResponse)
        val btnSubmit=findViewById<Button>(R.id.btnSubmit)
        var question = "Propose une recette en piochant parmi les ingrédients suivants :"
        btnSubmit.setOnClickListener {
            productList.observe(this) { products: List<Product> ->
                products.forEach { product: Product ->
                    val quantity = product.productQuantity
                    val productName = product.productName
                    question += "\n ${product.productName} (quantité: ${product.productQuantity})"
                    println("Product: $productName, Quantity: $quantity")
                }
            }
        }

            getResponse(question) { response ->
                        runOnUiThread {
                            txtResponse.text = response
                        }
                    }
                }
            }



// refactor and use retrofit
    suspend fun getResponse(question: String): String {
        val client = OkHttpClient()
        val apiKey = "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"
        val url = "https://api.openai.com/v1/chat/completions"

        val requestBody = """
        {
            "prompt": "$question",
            "max_tokens": 500,
            "temperature": 0
        }
    """.trimIndent()

        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(requestBody.toRequestBody("application/json".toMediaTypeOrNull()))
            .build()

        return withContext(Dispatchers.IO) {
            try {
                val response = client.newCall(request).execute()
                val body = response.body?.string()
                if (body != null) {
                    val jsonObject = JSONObject(body)
                    val jsonArray: JSONArray = jsonObject.getJSONArray("choices")
                    jsonArray.getJSONObject(0).getString("text")
                } else {
                    ""
                }
            } catch (e: IOException) {
                e.printStackTrace()
                ""
            }
        }
    }
}
*/


