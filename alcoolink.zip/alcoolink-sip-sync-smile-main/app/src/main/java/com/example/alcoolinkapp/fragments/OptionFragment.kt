package com.example.alcoolinkapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.alcoolinkapp.R

class OptionFragment : Fragment() {
/*
    lateinit var produitsRV : RecyclerView
    lateinit var list:List<Product>
    lateinit var produitsViewModel: ProduitsViewModel

 */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_option, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val btnNextPage: Button = view.findViewById(R.id.buttonPage7)
        btnNextPage.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_optionFragment_to_stockFragment)
        }

        val btnNextPage2: Button = view.findViewById(R.id.buttonPage8)
        btnNextPage2.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_optionFragment_to_mrcuisineFragment)
        }

        val btnNextPage3: Button = view.findViewById(R.id.buttonPage9)
        btnNextPage3.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_optionFragment_to_remplirViderFragment)
        }
    }

}