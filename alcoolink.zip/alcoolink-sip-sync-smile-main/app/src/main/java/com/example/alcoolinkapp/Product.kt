package com.example.alcoolinkapp



import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "productList")
data class Product(
    @ColumnInfo(name = "productName")
    var productName: String,

    @ColumnInfo(name = "productQuantity")
    var productQuantity: Int,
/*
    @ColumnInfo(name = "productPrice")
    var productPrice: Int,

    @ColumnInfo(name = "purchaseDate")
    var purchaseDate: String,

    @ColumnInfo(name = "bbDate")
    var bbDate: String,
*/
) {
    @PrimaryKey(autoGenerate = true)
    var id: Int? = null
}
