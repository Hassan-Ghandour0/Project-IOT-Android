package com.example.alcoolinkapp

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.alcoolinkapp.services.getResponse
import kotlinx.coroutines.launch

class ProductViewModel(val application: Context): ViewModel(){
    fun getAllProduct(): LiveData<List<Product>> {
        return productDao.getAllProduct()
    }
    fun getGPTProduct(): LiveData<List<Product>> {
        return productDao.getGPTProduct()
    }

    private lateinit var productDao: ProductDao
    private val AllProductList: LiveData<List<Product>>
    private val GPTProductList: LiveData<List<Product>>
    var promptGPT = "Propose une recette en piochant parmi les ingrédients suivants :"
    init {
        productDao = ProductDatabase.getDatabase(application).productDao()
        AllProductList = productDao.getAllProduct()
        GPTProductList = productDao.getGPTProduct()
        suspend { gptPromptMaker() }
        var GPTResponse = suspend { getResponse(promptGPT) }
            }

        private fun gptPromptMaker() {
                viewModelScope.launch {
                    val products = GPTProductList.value
                    products?.forEach { product ->
                        val quantity = product.productQuantity
                        val productName = product.productName
                        promptGPT += "\n ${product.productName} (quantité: ${product.productQuantity})"
                    }

        }
    }
    fun getGPTResponse(): LiveData<String> {
        return MutableLiveData<String>().apply {
            viewModelScope.launch {
                value = getResponse(promptGPT)
            }
        }
    }

}
