package com.example.alcoolinkapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProductAdapter (
    var list: List<Product>,
    val productClickInterface: ProductClickInterface
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {
    inner class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val nomTV = itemView.findViewById<TextView>(R.id.idTVNom)
        val quantiteTV = itemView.findViewById<TextView>(R.id.idTVQuantite)
        //val prixTV = itemView.findViewById<TextView>(R.id.idTVPrix)
        //val lienTV = itemView.findViewById<TextView>(R.id.idTVLien) // balise <TextView> à changer si on change le lien en image
        //val totalTV = itemView.findViewById<TextView>(R.id.idTVprixtottxt)
        val retirerTV = itemView.findViewById<ImageView>(R.id.idTVRetirer)
    }

    interface ProductClickInterface{
        fun onItemClick(Product: Product)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.produit_rv,parent, false)
        return ProductViewHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.nomTV.text = list.get(position).productName
        holder.quantiteTV.text = list.get(position).productQuantity.toString()
        //holder.prixTV.text = list.get(position).productPrice.toString()+".€"
        //val quantiteTotal: Int = list.get(position).prixProduit * list.get(position).quantiteProduit
        //holder.totalTV.text = quantiteTotal.toString()+".€"
        holder.retirerTV.setOnClickListener{
            productClickInterface.onItemClick(list.get(position))
        }
    }

}