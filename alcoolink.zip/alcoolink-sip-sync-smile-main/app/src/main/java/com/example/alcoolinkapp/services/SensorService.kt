package com.example.alcoolinkapp.services

import com.example.alcoolinkapp.SensorData
import retrofit2.Response
import retrofit2.http.GET


interface SensorService {
    @GET("/data")  // endpoint
    suspend fun fetchSensorData(): Response<SensorData>
}
