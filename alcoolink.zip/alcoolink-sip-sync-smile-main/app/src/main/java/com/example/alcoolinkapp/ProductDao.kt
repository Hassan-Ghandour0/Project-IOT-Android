package com.example.alcoolinkapp


import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ProductDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(item: Product)

    @Delete
    suspend fun deleteProduct(item: Product)

    @Query("SELECT * FROM productList")
    fun getAllProduct(): LiveData<List<Product>>

    @Query ("SELECT productQuantity, productName FROM productList")
    fun getGPTProduct(): LiveData<List<Product>>
}