/*
class NetworkService {
    private var SERVER_IP = "10.224.0.210" // Raspberry Pi IP address
    private var SERVER_PORT = 9999 // Server port

    fun fetchData(): String? {
        var socket: Socket? = null

        return try {
            socket = Socket(SERVER_IP, SERVER_PORT)
            val input = BufferedReader(InputStreamReader(socket.getInputStream()))

            // Read the response and convert to string
            var responseData = input.readLine()
            input.close()
            responseData
        } catch (e: Exception) {
            e.printStackTrace()
            null
        } finally {
            socket?.close()
        }
    }
}
*/