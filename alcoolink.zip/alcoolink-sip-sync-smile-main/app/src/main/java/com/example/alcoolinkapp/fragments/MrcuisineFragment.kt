package com.example.alcoolinkapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.example.alcoolinkapp.ProductViewModel
import com.example.alcoolinkapp.R

class MrcuisineFragment : Fragment() {
 lateinit var productViewModel : ProductViewModel
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_mrcuisine, container, false)

    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        productViewModel = ProductViewModel(requireContext())




        val btnNextPage: Button = view.findViewById(R.id.buttonPage4)
        btnNextPage.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_mrcuisineFragment_to_stockFragment)
        }

        val btnNextPage2: Button = view.findViewById(R.id.buttonPage5)
        btnNextPage2.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_mrcuisineFragment_to_optionFragment)
        }

        val btnNextPage3: Button = view.findViewById(R.id.buttonPage6)
        btnNextPage3.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_mrcuisineFragment_to_remplirViderFragment)
        }

        val txtResponse: TextView = view.findViewById(R.id.txtResponse)
        val btn: Button = view.findViewById(R.id.btnSubmit)

        btn.setOnClickListener {
            productViewModel.getGPTResponse().observe(viewLifecycleOwner, Observer { response ->
                txtResponse.text = response
            })
        }
        /*
            //fragment
            val txtResponse=view.findViewById<TextView>(R.id.txtResponse)
            val btnSubmit=view.findViewById<Button>(R.id.btnSubmit)

            //viewmodel
            val productList = productViewModel.getAllProduct()
            var question = "Propose une recette en piochant parmi les ingrédients suivants :"
            btnSubmit.setOnClickListener {

// to change with the get GPTproducts
                productList.observe(this) { products: List<Product> ->
                    products.forEach { product: Product ->
                        val quantity = product.productQuantity
                        val productName = product.productName
                        question += "\n ${product.productName} (quantité: ${product.productQuantity})"
                        println("Product: $productName, Quantity: $quantity")
                    }
                }
            }
        // viewmodel
            APIService.getResponse(question) { response ->
                runOnUiThread {
                    txtResponse.text = response
                }
            }
*/
// replace livedata with suspended functions

    }
}

