package com.example.alcoolinkapp.services.network

import com.example.alcoolinkapp.services.ChatGPTService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitSetup {


    val gptretrofit = Retrofit.Builder()
        .baseUrl("https://api.openai.com/v1/chat/completions/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val service = gptretrofit.create(ChatGPTService::class.java)

}
