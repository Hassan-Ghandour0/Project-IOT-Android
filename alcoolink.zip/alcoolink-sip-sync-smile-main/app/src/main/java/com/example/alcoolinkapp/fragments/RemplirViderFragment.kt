package com.example.alcoolinkapp.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController
import com.example.alcoolinkapp.R

class RemplirViderFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_remplir_vider, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val btnNextPage: Button = view.findViewById(R.id.buttonPage1)
        btnNextPage.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_remplirViderFragment_to_stockFragment)
        }

        val btnNextPage2: Button = view.findViewById(R.id.buttonPage2)
        btnNextPage2.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_remplirViderFragment_to_optionFragment)
        }

        val btnNextPage3: Button = view.findViewById(R.id.buttonPage3)
        btnNextPage3.setOnClickListener {
            val navController = findNavController()
            navController.navigate(R.id.action_remplirViderFragment_to_mrcuisineFragment)
        }
    }
}